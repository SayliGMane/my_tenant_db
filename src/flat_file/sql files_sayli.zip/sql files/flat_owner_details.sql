\c my_assessment_db sayli_user

CREATE TABLE private_data.flat_owner_details(
    FlatNo INT PRIMARY KEY,
    Owner VARCHAR(20) NOT NULL      
);

INSERT INTO private_data.flat_owner_details VALUES
(032,'Ravindra Navale'),
(034,'Ravindra Navale'),
(012,'Sayli Mane'),
(011,'Sayli Mane'),
(004,'Ravindra Navale');

SELECT * FROM private_data.flat_owner_details;